#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# File Name: adkit/__init__.py
# Author: fanyongtao
# mail: jacketfan826@gmail.com
# Created Time: 2015年05月08日 星期五 16时03分21秒
#########################################################################
__version__ = '0.0.2'
